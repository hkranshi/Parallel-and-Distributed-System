package mr

//
// RPC definitions.
//
// remember to capitalize all names.
//

import "os"
import "strconv"

//
// example to show how to declare the arguments
// and reply for an RPC.
//

type ExampleArgs struct {
	X int
}

type ExampleReply struct {
	Y int
}

// Add your RPC definitions here.

type MrArgs struct {
}


type MrReply struct {
	MapFileName string
	TaskType    string
	Index       int
	NReduce     int
	Files       []string
}

type NotifyIntermediateArgs struct {
	ReduceIndex int
	File        string
}

type NotifyMapSuccessArgs struct {
	File string
}

type NotifyReduceSuccessArgs struct {
	ReduceIndex int
}

type NotifyReply struct {
	
}

// Add your RPC definitions here.


func coordinatorSock() string {
	s := "/var/tmp/cs612-mr-"
	s += strconv.Itoa(os.Getuid())
	return s
}